#%%


import traceback
import PolyReg 

import logging

#%%

def run_analytic(data_json):
    """
    runs module
    Writes result in json file in 'Output' directory
    file_json_input : str, input json file name with path
    """
    try:
        
        values = PolyReg.polyregression(data)
        return values
    except Exception, e:
        logging.error('Error in run_analytic', str(e))
       
        traceback.print_exc()
        
        